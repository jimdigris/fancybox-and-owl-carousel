// галлерея
(() => { Fancybox.bind("[data-fancybox]", {}); })();

// слайдер owlCarousel - start
(() => {
    const slider__data = {
        loop: false,
        autoplay: true,
        rewind: true,
        autoplayTimeout: 5000,
        smartSpeed: 3000,
        autoplayHoverPause: true,
        items: 1,
        nav: false,
        dots: false,
        responsive: {
            1200: { items: 4 },
            767: { items: 3 },
            575: { items: 2 }
        },
        element_class: 'owl-fancybox-images'
    };

    class OwlCarousel {
        constructor(data) { this.data = data; }
        init() { if (this.#find_element()) { this.#launch_slider(); } }
        #find_element() { return document.querySelector(`.${this.data.element_class}`); }
        #launch_slider() { $(`.${this.data.element_class}`).owlCarousel(this.data); }
    }

    let slider = new OwlCarousel(slider__data);
    slider.init();
})();